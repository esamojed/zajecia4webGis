require (["esri/Map",
"esri/views/MapView",
"esri/WebMap",
"esri/geometry/support/webMercatorUtils",
"esri/widgets/BasemapGallery",
"esri/layers/GraphicsLayer",
"esri/widgets/Sketch",
"esri/layers/FeatureLayer"
],

function(Map, MapView,WebMap,webMercatorUtils,BasemapGallery,GraphicsLayer,Sketch,FeatureLayer){
    /*let map1 =new Map({basemap:"satellite"});
    let map2 =new Map({basemap:"topo"});
    let map3 =new Map({basemap:"osm"});*/
    let graphicsLayer = new GraphicsLayer();

    let map4 =new WebMap({
    portalItem: {
        id:"aaa3493acb9041dc98b3f65ec2dc9780"
     },        layers: [graphicsLayer]
    });
   


    let mapview= new MapView({
        container: "mapview",
        map: map4,
        center: [-0.6473200,51.6121900],
        zoom: 14,

    });
/*
    document.getElementById("satellite").addEventListener('click',
    function (){
        mapview.map=map1;
    })
    document.getElementById("topo").addEventListener('click',
    function (){
        mapview.map=map2;
    })
    document.getElementById("osm").addEventListener('click',
    function (){
        mapview.map=map3;
    });
*/
    mapview.on("click", function(evt){
        let cords = webMercatorUtils.webMercatorToGeographic(evt.mapPoint);
        cords.x.toFixed(5);
        cords.y.toFixed(5);
    });
    
    //widget do rysowania
    let sketch = new Sketch({
        view: mapview,
        layer: graphicsLayer
      });

      mapview.ui.add(sketch, "top-right");

    //galeria map bazowych
    let basemapGallery = new BasemapGallery({
        view: mapview,
        source: {
          portal: {
            url: "https://www.arcgis.com",
            useVectorBasemaps: true  
          }
        }
      })
      mapview.ui.add(basemapGallery, "top-right");

    //warstwa USA
      let trailheadsLayer = new FeatureLayer({
        url: "https://services3.arcgis.com/GVgbJbqm8hXASVYi/ArcGIS/rest/services/USA%20States/FeatureServer/0"
      });

      map4.add(trailheadsLayer);
    
    })