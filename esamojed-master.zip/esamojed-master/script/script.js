require (["esri/Map","esri/views/MapView"],
function(Map, MapView){
    let map1 =new Map({basemap:"topo"});
    let map2 =new Map({basemap:"gray"});
    let map3 =new Map({basemap:"satellite"});

    let mapview= new MapView({
        container: "mapview",
        map: map1,
        center: [00.000,-00.000],//poprawic
        zoom: 12
    });
    
    })