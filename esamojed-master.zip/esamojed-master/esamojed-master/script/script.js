require (["esri/Map","esri/views/MapView","esri/WebMap","esri/geometry/support/webMercatorUtils"],
function(Map, MapView,WebMap,webMercatorUtils){
    let map1 =new Map({basemap:"satellite"});
    let map2 =new Map({basemap:"topo"});
    let map3 =new Map({basemap:"osm"});
    let map4 =new WebMap({
    portalItem: {
        id:"aaa3493acb9041dc98b3f65ec2dc9780"
     }
    });
   

    let mapview= new MapView({
        container: "mapview",
        map: map4,
        zoom: 2
    });

    document.getElementById("satellite").addEventListener('click',
    function (){
        mapview.map=map1;
    })
    document.getElementById("topo").addEventListener('click',
    function (){
        mapview.map=map2;
    })
    document.getElementById("osm").addEventListener('click',
    function (){
        mapview.map=map3;
    });

    mapview.on("click", function(evt){
        let cords = webMercatorUtils.webMercatorToGeographic(evt.mapPoint);
        cords.x.toFixed(5);
        cords.y.toFixed(5);
    });
    
    })